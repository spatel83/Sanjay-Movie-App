# Hooks Movie App
This is the demo application using React Hooks!!!



# Getting Started
These instructions should get you a copy of the project up and running on your local machine for development and testing purposes.



# Installing
To get the project running, follow these steps:
- Create a folder
-Enter/Navigate into that folder

cd <folder-name>




- Install all the project's dependencies:
```
yarn or npm install
```
- Once that's done, run the project:
```
npm start or yarn start
```



# Built With
- Javascript
- React - (UI library)

#
